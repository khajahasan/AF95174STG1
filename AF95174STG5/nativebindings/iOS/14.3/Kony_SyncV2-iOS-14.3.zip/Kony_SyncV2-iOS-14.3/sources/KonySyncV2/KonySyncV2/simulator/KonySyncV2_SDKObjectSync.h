#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_KonySyncV2_SDKObjectSync_symbols(JSContext*);
@protocol SDKObjectSyncInstanceExports<JSExport>
JSExportAs(initWithNameError,
-(id) jsinitWithName: (id) name error: (id) error );
JSExportAs(initWithNameAndObjectServiceNameError,
-(id) jsinitWithName: (id) name andObjectServiceName: (id) objectServiceName error: (id) error );
JSExportAs(startSyncOnSuccessOnFailureOnProgress,
-(void) jsstartSync: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress );
JSExportAs(getPendingRecordsForUploadOnSuccessOnFailure,
-(void) jsgetPendingRecordsForUpload: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(createOptionsOnSuccessOnFailure,
-(void) jscreate: (id) record options: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(updateByPKOptionsOnSuccessOnFailure,
-(void) jsupdateByPK: (id) record options: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(updateOptionsOnSuccessOnFailure,
-(void) jsupdate: (id) record options: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(deleteByPKOnSuccessOnFailure,
-(void) jsdeleteByPK: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(deleteOnSuccessOnFailure,
-(void) jsdelete: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(getOnSuccessOnFailure,
-(void) jsget: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(rollbackOnSuccessOnFailure,
-(void) jsrollback: (id) primaryKeyValueMap onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(getBinaryDownloadStartedHandlerChunkDownloadCompletedHandlerStreamDownloadCompletedHandlerFileDownloadCompletedHandlerDownloadFailureHandler,
-(void) jsgetBinary: (id) options downloadStartedHandler: (JSValue *) fileDownloadStartedCompletionBlock chunkDownloadCompletedHandler: (JSValue *) chunkDownloadCompletedCompletionBlock streamDownloadCompletedHandler: (JSValue *) streamDownloadCompletionBlock fileDownloadCompletedHandler: (JSValue *) fileDownloadCompletedCompletionBlock downloadFailureHandler: (JSValue *) downloadFailureCompletionBlock );
JSExportAs(getBinaryStatusOnSuccessOnFailure,
-(void) jsgetBinaryStatus: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(markForUploadOnSuccessOnFailure,
-(void) jsmarkForUpload: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(getUploadDeferredRecordKeysOnFailure,
-(void) jsgetUploadDeferredRecordKeys: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(cancelSyncOnFailure,
-(void) jscancelSync: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(clearDataWithOptionsOnSuccessOnFailure,
-(void) jsclearDataWithOptions: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
@end
@protocol SDKObjectSyncClassExports<JSExport>
@end
#pragma clang diagnostic pop