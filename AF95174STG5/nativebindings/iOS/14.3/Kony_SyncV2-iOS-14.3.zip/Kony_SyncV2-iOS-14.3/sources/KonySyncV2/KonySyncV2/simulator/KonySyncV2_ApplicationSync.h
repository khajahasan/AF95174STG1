#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_KonySyncV2_ApplicationSync_symbols(JSContext*);
@protocol ApplicationSyncInstanceExports<JSExport>
@end
@protocol ApplicationSyncClassExports<JSExport>
+(void) setToken: (id) token ;
+(void) setReportingParams: (id) reportingParams ;
JSExportAs(setupSyncWithOptionsOnSuccessOnFailure,
+(void) jssetupSync: (id) objectServiceList withOptions: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(dropOnSuccessOnFailure,
+(void) jsdrop: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(resetWithOptionsOnSuccessOnFailure,
+(void) jsreset: (id) objectServiceList withOptions: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(rollbackOnFailure,
+(void) jsrollback: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(executeSelectQueryOnSuccessOnFailure,
+(void) jsexecuteSelectQuery: (id) query onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure );
JSExportAs(startSyncOnSuccessOnFailureOnProgress,
+(void) jsstartSync: (id) options onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress );
@end
#pragma clang diagnostic pop