#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_SDKCommons_KNYGlobalRequestParams_symbols(JSContext*);
@protocol KNYGlobalRequestParamsInstanceExports<JSExport>
@end
@protocol KNYGlobalRequestParamsClassExports<JSExport>
+(void) setGlobalRequestParam: (id) paramName paramValue: (id) paramValue paramType: (id) paramType ;
+(id) getGlobalRequestParams: (id) paramType ;
+(void) removeGlobalRequestParam: (id) paramName paramType: (id) paramType ;
+(void) resetGlobalRequestParams;
@end
#pragma clang diagnostic pop