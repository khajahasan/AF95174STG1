#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Binary_BinaryFileStorageInterface_symbols(JSContext*);
@protocol BinaryFileStorageInterfaceInstanceExports<JSExport>
@end
@protocol BinaryFileStorageInterfaceClassExports<JSExport>
JSExportAs(getFilesWithUrlCriteriaHeadersOnSuccessOnFailureOptions,
+(void) jsgetFilesWithUrl: (id) url criteria: (id) criteria headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options );
JSExportAs(uploadBinaryWithUrlInputTypeUploadParamsOnSuccessOnFailureOnProgressOptions,
+(void) jsuploadBinaryWithUrl: (id) url InputType: (id) uploadInputType uploadParams: (id) uploadParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress options: (id) options );
JSExportAs(downloadWithURLParamsOnSuccessOnFailureOnProgressOptions,
+(void) jsdownloadWithURL: (id) url Params: (id) downloadParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress options: (id) options );
JSExportAs(updateWithUrlParamsOnSuccessOnFailureOptions,
+(void) jsupdateWithUrl: (id) url Params: (id) updateParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options );
JSExportAs(deleteWithUrlFileIdDeleteParamsHeadersOnSuccessOnFailureOptions,
+(void) jsdeleteWithUrl: (id) url fileId: (id) fileId deleteParams: (id) deleteParams headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options );
JSExportAs(deleteByCriteriaDeleteCriteriaHeadersOnSuccessOnFailureOptions,
+(void) jsdeleteByCriteria: (id) url deleteCriteria: (id) deleteCriteria headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options );
JSExportAs(abortWithUrlFileIdAbortParamsHeadersOnSuccessOnFailureOptions,
+(void) jsabortWithUrl: (id) url fileId: (id) fileId abortParams: (id) abortParams headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options );
@end
#pragma clang diagnostic pop