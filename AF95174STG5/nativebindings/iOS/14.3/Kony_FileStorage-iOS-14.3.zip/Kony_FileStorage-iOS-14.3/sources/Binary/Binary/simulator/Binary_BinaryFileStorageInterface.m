#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation BinaryFileStorageInterface (Exports)
+(void) jsgetFilesWithUrl: (id) url criteria: (id) criteria headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	[self getFilesWithUrl: url criteria: criteria headers: headers onSuccess: onSuccess_ onFailure: onFailure_ options: options ];
}
+(void) jsuploadBinaryWithUrl: (id) url InputType: (id) uploadInputType uploadParams: (id) uploadParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	void (^ onProgress_)(int) = nil;
	if (!onProgress.isUndefined) {
		onProgress_ = ^void(int arg0) {
			JSContext* __jsContext = onProgress.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onProgress, self, parameters);
		};
	}
	[self uploadBinaryWithUrl: url InputType: uploadInputType uploadParams: uploadParams onSuccess: onSuccess_ onFailure: onFailure_ onProgress: onProgress_ options: options ];
}
+(void) jsdownloadWithURL: (id) url Params: (id) downloadParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure onProgress: (JSValue *) onProgress options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	void (^ onProgress_)(int) = nil;
	if (!onProgress.isUndefined) {
		onProgress_ = ^void(int arg0) {
			JSContext* __jsContext = onProgress.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onProgress, self, parameters);
		};
	}
	[self downloadWithURL: url Params: downloadParams onSuccess: onSuccess_ onFailure: onFailure_ onProgress: onProgress_ options: options ];
}
+(void) jsupdateWithUrl: (id) url Params: (id) updateParams onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	[self updateWithUrl: url Params: updateParams onSuccess: onSuccess_ onFailure: onFailure_ options: options ];
}
+(void) jsdeleteWithUrl: (id) url fileId: (id) fileId deleteParams: (id) deleteParams headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	[self deleteWithUrl: url fileId: fileId deleteParams: deleteParams headers: headers onSuccess: onSuccess_ onFailure: onFailure_ options: options ];
}
+(void) jsdeleteByCriteria: (id) url deleteCriteria: (id) deleteCriteria headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	[self deleteByCriteria: url deleteCriteria: deleteCriteria headers: headers onSuccess: onSuccess_ onFailure: onFailure_ options: options ];
}
+(void) jsabortWithUrl: (id) url fileId: (id) fileId abortParams: (id) abortParams headers: (id) headers onSuccess: (JSValue *) onSuccess onFailure: (JSValue *) onFailure options: (id) options 
{
	void (^ onSuccess_)(int) = nil;
	if (!onSuccess.isUndefined) {
		onSuccess_ = ^void(int arg0) {
			JSContext* __jsContext = onSuccess.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onSuccess, self, parameters);
		};
	}
	void (^ onFailure_)(int) = nil;
	if (!onFailure.isUndefined) {
		onFailure_ = ^void(int arg0) {
			JSContext* __jsContext = onFailure.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, onFailure, self, parameters);
		};
	}
	[self abortWithUrl: url fileId: fileId abortParams: abortParams headers: headers onSuccess: onSuccess_ onFailure: onFailure_ options: options ];
}
@end
static void addProtocols()
{
	class_addProtocol([BinaryFileStorageInterface class], @protocol(BinaryFileStorageInterfaceInstanceExports));
	class_addProtocol([BinaryFileStorageInterface class], @protocol(BinaryFileStorageInterfaceClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_Binary_BinaryFileStorageInterface_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
