
const { app, ipcMain } = require('electron');
const { newResult } = require('./utils');
const { uuid } = require('uuidv4');
const sqlite3  = require('sqlite3');
const { open } = require('sqlite');
const fs = require('fs');
const path = require('path');

const { getDbObjectId, getDbObjectFromId, DbObjectWrapper, setDbObjectId, removeDbObjectId } = require('./dbUtils');
const constants = require('./voltmxDbConstants.json');
const dbBootstrap = require('./voltmxDbApiBootstrap');

function volmxDbHandlers(context) {

    ipcMain.on(dbBootstrap.channel_db_bootstrap,  (event, args) => {
        event.returnValue = dbBootstrap;
    })

    ipcMain.on(dbBootstrap.channel_db_executeSql, async (event, transactionId, sqlStatement, args) => {
        console.debug(`on ${dbBootstrap.channel_db_executeSql}`);
        const result = newResult();
        const dbObjectWrapper = getDbObjectFromId(transactionId);
        try {
            if (dbObjectWrapper) {
                try {
                    if (dbObjectWrapper.dbObjectType === constants.type_transaction) {
                        dbObjectWrapper.dbObject.exec(sqlStatement, undefined, () => {
                                console.log("executeSql successful");
                                result.value = true;
                                resolve(result);
                            }, 
                            (t) => {
                                console.log(`An error occurred during executeSql`);
                                result.error = new Error('An error occurred trying to execute the sql statement.');
                                resolve(result);
                            })
                    } else {
                        try {
                            const sqlArgs = args === null ? [] : args;
                            const sqlRes =  await dbObjectWrapper.dbObject.all(sqlStatement, sqlArgs);
                            console.log("executeSql successful");
                            // result.value = rows;
                            result.value = sqlRes;
                        } catch (allErr) {
                            result.error = allErr;
                        }
                    }
                } catch (err) {
                    result.error = err;
                }
            } else {
                result.error = new Error("Database or transaction could not be found to execute sql");
            }
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    });

    ipcMain.on(dbBootstrap.channel_db_openDatabase, async (event, dbName, version, displayName, estimatedSize) => {
        console.debug(`on ${dbBootstrap.channel_db_openDatabase}`);

        // Check if the database file exists
        const isDatabaseNew = !fs.existsSync(dbName);
        // Check if dbName contains the complete path
        const isAbsolutePath = path.isAbsolute(dbName);
        // If dbName doesn't contain the complete path, use the default path and append dbName
        const defaultPath = path.join(app.getPath('userData'), 'data');
        const fullPath = isAbsolutePath ? dbName : path.join(defaultPath, dbName);
        const directory = path.dirname(fullPath);
        if (!fs.existsSync(directory)) {
            fs.mkdirSync(directory, { recursive: true });
        }

        const db = await open({
            filename: fullPath,
            driver: sqlite3.cached.Database
        });

        // const db = openDatabase(dbName, version, displayName, estimatedSize ?? (1024 * 5));
        const result = newResult();
        if (db) {
            // Check if the database file is being created for the first time
            if (isDatabaseNew) {
                if (parseInt(version) !== 0)
                    db.run(`PRAGMA user_version=${version}`);
            } else if (version) {
                // The database file already exists, check the version
                let currentVersion;
                const dbresult = await db.all(`PRAGMA user_version`);
                if (dbresult) {
                    currentVersion = dbresult[0].user_version;
                }
                // Check if the requested version is different from the current version
                if (parseInt(version) !== parseInt(currentVersion)) {
                    result.error = new Error(`Requested version ${version} does not match current version ${currentVersion}`);
                }
            }
            if (!result.error) {
                let id = getDbObjectId(db);
                if (!id) {
                    id = uuid();
                    setDbObjectId(new DbObjectWrapper(db, constants.type_db), id);
                }
                result.value = id
            }
        }
        event.returnValue = result;
    });
    
     ipcMain.on(dbBootstrap.channel_db_closeDatabase, async (event, dbId) => {
        console.debug(`on ${dbBootstrap.channel_db_closeDatabase}`);

        const result = newResult();
        const dbObjectWrapper = getDbObjectFromId(dbId);
        if (dbObjectWrapper) {
            try {
                dbObjectWrapper.dbObject.close();
            } catch (err) {
                // Do nothing...it'll be removed and closed by gc
            }
            removeDbObjectId(dbId);
            result.value = true;
        }
        event.returnValue = result;
    });
   
    ipcMain.on(dbBootstrap.channel_db_begin_transaction, async (event, dbaseObjectId) => {
        console.debug(`on ${dbBootstrap.channel_db_begin_transaction}`);
        const result = newResult();
        // const dbObjectWrapper = getDbObjectFromId(rendererTransactionId);
        const dbObjectWrapper = getDbObjectFromId(dbaseObjectId);
        try {
            if (dbObjectWrapper) {
                try {
                    const sqlStatement = "BEGIN TRANSACTION";
                    const res = await dbObjectWrapper.dbObject.run(sqlStatement, []);
                    console.log(res);
                    console.log("begin transaction successful");
                    result.value = true;
                } catch (err) {
                    result.error = err;
                }
            } else {
                result.error = new Error("Database or transaction could not be found to begin the transaction");
            }
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    });


    ipcMain.on(dbBootstrap.channel_db_commit_transaction, async (event, dbaseObjectId) => {
        console.debug(`on ${dbBootstrap.channel_db_commit_transaction}`);
        const result = newResult();
        const dbObjectWrapper = getDbObjectFromId(dbaseObjectId);
        try {
            if (dbObjectWrapper) {
                try {
                    const sqlStatement = "COMMIT TRANSACTION";
                    await dbObjectWrapper.dbObject.run(sqlStatement, []);
                    console.log("commit transaction successful");
                    result.value = true;
                } catch (err) {
                    result.error = err;
                }
            } else {
                result.error = new Error("Database or transaction could not be found to commit the transaction");
            }
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    });

    ipcMain.on(dbBootstrap.channel_db_rollback_transaction, async (event, dbaseObjectId) => {
        console.debug(`on ${dbBootstrap.channel_db_rollback_transaction}`);
        const result = newResult();
        // const dbObjectWrapper = getDbObjectFromId(rendererTransactionId);
        const dbObjectWrapper = getDbObjectFromId(dbaseObjectId);
        try {
            if (dbObjectWrapper) {
                try {
                    const sqlStatement = "ROLLBACK TRANSACTION";
                    await dbObjectWrapper.dbObject.run(sqlStatement, []);
                    console.log("rollback transaction successful");
                    result.value = true;
                } catch (err) {
                    result.error = err;
                }
            } else {
                result.error = new Error("Database or transaction could not be found to rollback the transaction");
            }
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    });
}

function loadAPIHandlers(context)  {
    this.volmxDbHandlers(context);
}
module.exports = {volmxDbHandlers, loadAPIHandlers};


