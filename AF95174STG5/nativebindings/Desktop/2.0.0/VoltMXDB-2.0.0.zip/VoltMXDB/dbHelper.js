const sqlite3 = require('@journeyapps/sqlcipher').verbose();
const { createDirectory, getAbsolutePath } = require('./utils');

/**
 * Singleton Class to handle SQLite database connection.
 */
class DbHelper {

    #MAX_SQL_CACHE_SIZE = 100;

    /**
     * Instantiates the SQLiteAndroidDatabaseHelper
     *
     * @param databaseName   the database name
     * @param encryptionKey  encryption key
     */
    constructor(databaseName, encryptionKey) {
        this.databaseName = databaseName;
        this.encryptionKey = encryptionKey;

        // sync.db path
        this.dbPath = `${getAbsolutePath()}/${this.databaseName}`;

        // create directory to store the data
        createDirectory(this.dbPath);

        // initializing the database
        this.db = new sqlite3.Database(this.dbPath);

        console.log(`Database get created successfully at ${this.dbPath}`);
    }

    /**
     * Get an instance of the SQLiteAndroidDatabaseHelper
     *
     * @param databaseName the database name
     * @return DbHelper
     */
    static getDBInstance(databaseName) {
        return DbHelper.createDBConnection(databaseName);
    }

    static createDBConnection(databaseName) {
        const dbInstance = new DbHelper(databaseName);

        dbInstance.db.run('PRAGMA foreign_keys=ON'); // Enable foreign key support

        dbInstance.setMaxSqlCacheSize();

        return dbInstance;
    }

    static setupDBWithEncryption(databaseName, encryptionKey) {
        try {
            const dbInstance = new DbHelper(databaseName, encryptionKey);

            dbInstance.db.run(`PRAGMA key='${dbInstance.encryptionKey}';`);
            dbInstance.db.run('PRAGMA cipher_compatibility = 3;');
            dbInstance.db.run('PRAGMA cipher_default_compatibility = 3;');
            dbInstance.db.run('PRAGMA cipher_default_kdf_iter = 4000;');
    
            console.log('Connected to the encrypted database');
    
            return dbInstance;   
        } catch (error) {
            console.error('Error opening encrypted database:', error.message);
            throw error;
        }
    }

    /**
     * Executes query with selection arguments for SELECT operation.
     *
     * @param sql           the query
     * @param selectionArgs the values to be bind
     * @return List of maps containing column names and their respective values of the selected
     * records.
     */
    async executeRawQuery(sql, selectionArgs, callback) {
        this.db.all(sql, selectionArgs, (error, rows) => {
          if (error) {
            console.error('Error executing raw query:', error.message);
            callback(error, null);
          } else {
            callback(null, rows);
          }
        });
      }

    setMaxSqlCacheSize() {
        const setCacheSizeQuery = `PRAGMA cache_size = ${this.#MAX_SQL_CACHE_SIZE};`;
        this.db.run(setCacheSizeQuery);
    }

    /**
     * Executes multiple raw queries for CREATE, INSERT, UPDATE and DELETE operations.
     * If any statement fails, the transaction is rolled back.
     *
     * @param queries         A list of queries.
     * @param rollbackOnError If set to true, entire transaction is rolled back,
     *                        else result of successful queries are persisted to DB
     *                        and failed queries of the current transaction are ignored.
     * @throws VoltMXDatabaseException if any
     */
    executeQueries(queries, rollbackOnError) {
        return new Promise((resolve, reject) => {
            const db = this.db;

            db.serialize(() => {
                db.run('BEGIN TRANSACTION', (err) => {
                    if (err) {
                        return reject(new Error(`Failed to begin transaction: ${err.message}`));
                    }

                    let queryIndex = 0;

                    const executeQuery = () => {
                        if (queryIndex >= queries.length) {
                            db.run('COMMIT', (commitErr) => {
                                if (commitErr) {
                                    if (rollbackOnError) {
                                        db.run('ROLLBACK', (rollbackErr) => {
                                            if (rollbackErr) {
                                                return reject(new Error(`Commit failed and rollback failed: ${rollbackErr.message}`));
                                            }
                                            return reject(new Error(`Commit failed: ${commitErr.message}`));
                                        });
                                    } else {
                                        return reject(new Error(`Commit failed: ${commitErr.message}`));
                                    }
                                } else {
                                    resolve(); // Commit successful, resolve the promise
                                }
                            });
                            return;
                        }

                        const query = queries[queryIndex];
                        db.run(query, function (stmtErr) {
                            if (stmtErr) {
                                if (rollbackOnError) {
                                    db.run('ROLLBACK', (rollbackErr) => {
                                        if (rollbackErr) {
                                            return reject(new Error(`Rollback failed after query failure: ${rollbackErr.message}`));
                                        }
                                        return reject(new Error(`Query failed: ${query}. Error: ${stmtErr.message}`));
                                    });
                                } else {
                                    console.warn(`Query failed: ${stmtErr.message}. Continuing without rollback.`);
                                    queryIndex++; // Move to the next query if rollbackOnError is false
                                    executeQuery(); // Execute next query
                                }
                            } else {
                                queryIndex++; // Move to the next query if successful
                                executeQuery(); // Execute next query
                            }
                        });
                    };

                    // Start executing the first query
                    executeQuery();
                });
            });
        });
    }

    /**
     * Executes prepared statements for CREATE, INSERT, UPDATE and DELETE operations.
     * If any statement fails, the transaction is rolled back.
     *
     * @param statements      List of prepared queries
     * @param rollbackOnError If set to true, entire transaction is rolled back,
     *                        else result of successful queries are persisted to DB
     *                        and failed queries of the current transaction are ignored.
     * @throws VoltMXDatabaseException if any
     */
    executePreparedStatements(statements, rollbackOnError) {
        const transactionIDs = [];

        return new Promise((resolve, reject) => {
            // Start the transaction
            this.db.serialize(() => {
                this.db.run('BEGIN TRANSACTION', (err) => {
                if (err) {
                    return reject([err, null]); // Transaction failed to start
                }

                let statementsExecuted = 0;
                const totalStatements = statements.length;

                const runStatement = async (statement) => {
                    const [error, lastID] = await this.executePreparedStatement(
                        statement.query,
                        statement.values
                    );

                    if (error) {
                        this.db.run('ROLLBACK', (rollbackErr) => {
                            if (rollbackErr) {
                                console.error('Rollback failed', rollbackErr);
                            }
                            return reject([error, null]);
                        });

                        return;
                    }

                    transactionIDs.push(lastID);

                    statementsExecuted++;

                    if (statementsExecuted === totalStatements) {
                    // If all statements are executed successfully, commit the transaction
                    this.db.run('COMMIT', (commitErr) => {
                        if (commitErr) {
                            return reject([commitErr, null]);
                        }
                        resolve([null, transactionIDs]);
                    });
                    } else {
                        runStatement(statements[statementsExecuted]);
                    }
                };

                // Run the first statement
                if (statements.length > 0) {
                    runStatement(statements[0]);
                } else {
                    // If no statements are provided, commit immediately
                    this.db.run('COMMIT', (commitErr) => {
                        if (commitErr) {
                            return reject([commitErr, null]);
                        }

                        resolve([null, transactionIDs]);
                    });
                }
                });
            });
        });
    }

    executePreparedStatement(sqlQuery, values) {
        return new Promise((resolve, reject) => {
            // Prepare a statement
            const preparedStatement = this.compileAndBindSQLiteStatement(
                sqlQuery,
                values
            );

            let runError = null;
            let lastID = null;

            // Execute the statement
            preparedStatement.run(function (error) {
                if (error) {
                runError = error.message;
                console.error(`Error inserting data:`, error.message);
                } else {
                lastID = this.lastID;
                console.log(`Row inserted with ID: ${this.lastID}`);
                }

                // Finalize the statement to release resources
                preparedStatement.finalize((error) => {
                if (error) {
                    console.error('Error finalizing statement:', error.message);
                }

                resolve([runError || error?.message || null, lastID]);
                });
            });
        });
    }

    compileAndBindSQLiteStatement(sqlQuery, values) {
        const preparedStatement = this.db.prepare(sqlQuery);
        const parsedValues = [];

        for (const value of values) {
            const [dataType, dataValue] = value;

            switch (dataType) {
                case 'SQLTEXT':
                    parsedValues.push(String(dataValue));
                    break;
                case 'SQLINT':
                    parsedValues.push(parseInt(dataValue));
                    break;
                case 'SQLREAL':
                    parsedValues.push(parseFloat(dataValue));
                    break;
                case 'SQLBLOB':
                    parsedValues.push(Buffer.from(dataValue));
                    break;
                default:
                    parsedValues.push(null);
                    break;
            }
        }

        // Binds parameters to the prepared statement
        preparedStatement.bind(...parsedValues);

        return preparedStatement;
    }

    performRollbackOperation(rollbackOnError, error) {
        if (rollbackOnError) {
            this.db.run('ROLLBACK');
            throw new Error(`Failed to execute prepared statement. Error: ${error.message}`);
        } else {
            console.warn(`Warning: ${error.message}`);
        }
    }

    /**
     * Executes raw query for SELECT operation.
     *
     * @param {string} sql - The SQL query to be executed for SELECT operation.
     * @param {function} callback - A callback function to handle the results of the query.
     *   @param {Error|null} err - An error object if any query encounters an error, otherwise null.
     *   @param {Array<Record<string, any>>|null} rows - An array of maps containing column names
     *      and their respective values of the selected records. Null if an error occurs.
     *
     */
    executeSelectQuery(sql, callback) {
        this.db.all(sql, (err, rows) => {
            if (err) {
                callback(err, null);
            } else {
                callback(null, rows);
            }
        });
    }

    /**
     * Executes a prepared statement for SELECT operation.
     *
     * @param {string} sql - The SQL query with placeholders for prepared statement.
     * @param {Array<any>} selectionArgs - Values to be bound to the prepared statement placeholders.
     * @param {function} callback - A callback function to handle the results of the query.
     *   @param {Error|null} err - An error object if the query encounters an error, otherwise null.
     *   @param {Array<Record<string, any>>|null} rows - An array of maps containing column names
     *      and their respective values of the selected records. Null if an error occurs.
     */
    executeSelectPreparedStatements(sql, selectionArgs, callback) {
        this.db.all(sql, selectionArgs, (err, rows) => {
            if (err) {
                callback(err, null);
            } else {
                callback(null, rows);
            }
        });
    }

    executeInsertPreparedStatement(sqlQuery, selectionArgs, rollbackOnError) {
        const preparedStatement = this.compileAndBindSQLiteStatement(sqlQuery, selectionArgs);

        try {
            return preparedStatement.run().lastID;
        } catch (error) {
            this.performRollbackOperation(rollbackOnError, error);
            return -1;
        }
    }

    executeSingleInsertStatement(sqlQuery, selectionArgs, callback) {
        this.db.run('BEGIN TRANSACTION');

        try {
            const autoGeneratedId = this.executeInsertPreparedStatement(sqlQuery, selectionArgs, true);
            this.db.run('COMMIT');
            callback(null, autoGeneratedId);
        } catch (error) {
            this.db.run('ROLLBACK');
            callback(error, null);
        }
    }

    /**
     * Checks whether a table exists in the SQLite database.
     *
     * @param {string} tableName - The name of the table to check for existence.
     * @param {function} callback - A callback function to handle the result of the existence check.
     *   @param {Error|null} err - An error object if the existence check encounters an error, otherwise null.
     *   @param {boolean} isFound - A boolean indicating whether the specified table exists in the database.
     *       - `true` if the table is found.
     *       - `false` if the table is not found or an error occurs during the check.
     */
    isTableFound(tableName, callback) {
        /**
         * SQL query to check for the existence of the specified table in the database.
         * It selects a distinct table name from the sqlite_master table where the table name matches the specified one.
         */
        const query = `SELECT DISTINCT tbl_name FROM sqlite_master WHERE tbl_name = '${tableName}'`;

        this.db.get(query, (err, row) => {
            if (err) {
                // An error occurred during the existence check.
                callback(err, false);
            } else {
                // The existence check was successful.
                // The result is a boolean indicating whether the table is found.
                callback(null, !!row);
            }
        });
    }

    close() {
        this.db.close();
    }

    // Uncomment to test only
    // method will get removed before code merged
    /*createTableIfNotExists(cb) {
        const createTableQuery = `
            CREATE TABLE IF NOT EXISTS example_table (
                id INTEGER PRIMARY KEY,
                name TEXT
            )
        `;

        this.db.run(createTableQuery, (res, err) => {
            if (!err) cb();
        });
    }*/
}

module.exports = DbHelper;

// Example usage:
/*
const databaseName = 'example.db';
const dbInstance = DbHelper.createDBConnection(databaseName);

dbInstance.createTableIfNotExists(() => {
    const insertDataQuery = 'INSERT INTO example_table (name) VALUES (?)';
    const selectDataQuery = 'SELECT * FROM example_table';

    dbInstance.executePreparedStatement(insertDataQuery, [['SQLTEXT', 'John Doe']], console.log);

    dbInstance.executeSelectQuery(selectDataQuery, (err, rows) => {
        if (err) {
            console.error(`Error executing select query: ${err.message}`);
        } else {
            console.log('Selected data:', rows);
        }

        // dbInstance.close();
    });
});

dbInstance.isTableFound('example_table', (err, rows) => {
    if (err) {
        console.error(`Error executing select query: ${err.message}`);
    } else {
        console.log('Exist', rows);
    }

    dbInstance.close();
});
*/
