const dbIds = new Map();

function DbObjectWrapper(dbObject, dbObjectType) {
    this.dbObject = dbObject;
    this.dbObjectType = dbObjectType;
}

function getDbObjectFromId(id) {
    return dbIds.get(id);
}

function getDbObjectId(db) {
    for (let [key, value] of dbIds.entries()) {
        if (value === db) {
            return key;
        }
    }
    return undefined;
}

function setDbObjectId(db, id) {
    dbIds.set(id, db);
}

function removeDbObjectId(id) {
    if (id !== undefined) {
        dbIds.delete(id);
    }
}

module.exports = { DbObjectWrapper, getDbObjectFromId, getDbObjectId, setDbObjectId, removeDbObjectId }