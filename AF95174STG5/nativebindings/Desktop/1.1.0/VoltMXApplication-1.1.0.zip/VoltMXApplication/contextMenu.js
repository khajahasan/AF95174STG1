const defaultContextMenuTemplate = [
    { label: 'Cut', role: 'cut', accelerator: 'CmdOrCtrl+X' },
    { label: 'Copy', role: 'copy', accelerator: 'CmdOrCtrl+C' },
    { label: 'Paste', role: 'paste', accelerator: 'CmdOrCtrl+V' },
    { label: 'Select All', role: 'selectAll', accelerator: 'CmdOrCtrl+A' }
  ];
  
  /**
   * Merges two context menu templates.
   * 
   * @param {Array} existingTemplate - The existing context menu items.
   * @param {Array} newTemplate - The new context menu items to be merged.
   * @return {Array} - The merged context menu items.
   * @description
   * This function merges an existing context menu template with a new one.
   * If an item from the new template has the same label as an item in the existing template,
   * the existing item is replaced. Otherwise, the new item is added to the template.
   */
  function mergeTemplates(existingTemplate, newTemplate) {
    const merged = [...existingTemplate];
    newTemplate.forEach(newItem => {
      const index = merged.findIndex(existingItem => existingItem.label === newItem.label);
      if (index > -1) {
        merged[index] = newItem;
      } else {
        merged.push(newItem);
      }
    });
    return merged;
  }
  
  module.exports = { defaultContextMenuTemplate, mergeTemplates };